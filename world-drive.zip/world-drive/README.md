# World Drive
1. Create a GitHub repo and upload everything in this zip (keep the .github folder).
2. Open the Actions tab -> "Build APK" runs automatically on push.
3. Download app-debug.apk from the run's Artifacts and install it.
Needs internet (satellite tiles + place search). Test in a browser: open www/index.html.
